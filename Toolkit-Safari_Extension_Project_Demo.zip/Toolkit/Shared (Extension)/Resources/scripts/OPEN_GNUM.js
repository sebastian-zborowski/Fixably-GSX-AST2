(function () {
    'use strict';


  if (location.search.includes('dummy=1')) {
    console.log('Dummy page detected, skrypt nie wykonuje się tutaj.');
    return; 
  }

   const urlParams = new URLSearchParams(window.location.search);
    const openGnum = urlParams.get('opengnum');
    if (openGnum !== '1') return;

    const waitForContainer = () => {
        return new Promise((resolve) => {
            const observer = new MutationObserver((mutations, obs) => {
                const container = document.querySelector('#product-repairs');
                if (container) {
                    obs.disconnect();
                    resolve(container);
                }
            });

            observer.observe(document.body, { childList: true, subtree: true });
        });
    };

    const expandRepairSection = () => {
        const toggleBtn = document.querySelector('bricks-button[aria-expanded="false"] i.icon-arrow-expand-internal-sections-outline');
        if (toggleBtn) {
            toggleBtn.click();
        }
    };

    const findAndClickGnum = () => {
        const links = document.querySelectorAll('a[href^="/repairs/G"]');
        for (let link of links) {
            if (link.href.includes('/repairs/G')) {
                console.log('Clicking GNUM link:', link.href);
                link.click();
                return true;
            }
        }
        console.warn('GNUM link not found');
        return false;
    };

    waitForContainer().then(() => {
        setTimeout(() => {
            expandRepairSection();
            setTimeout(() => {
                findAndClickGnum();
            }, 500);
        }, 500);
    });

})();
 //13.08.2025
