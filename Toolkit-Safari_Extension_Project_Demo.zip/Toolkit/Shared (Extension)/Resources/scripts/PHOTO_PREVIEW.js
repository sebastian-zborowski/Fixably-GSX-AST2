(function() {
    'use strict';

    const SUPPORTED_IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.heic'];
    const SUPPORTED_PDF_EXTENSIONS = ['.pdf'];

    function isImageFile(href) {
        return SUPPORTED_IMAGE_EXTENSIONS.some(ext => href.toLowerCase().includes(ext));
    }

    function isPdfFile(href) {
        return SUPPORTED_PDF_EXTENSIONS.some(ext => href.toLowerCase().includes(ext));
    }

    function createPreviewPopup() {
        const popup = document.createElement('div');
        popup.id = 'filePreviewPopup';
        Object.assign(popup.style, {
            position: 'fixed',
            top: '20px',
            left: '20px',
            width: '35%',
            height: '65%',
            zIndex: '9999',
            border: '2px solid #444',
            borderRadius: '8px',
            boxShadow: '0 0 12px rgba(0,0,0,0.3)',
            background: 'gray',
            display: 'none',
            overflow: 'hidden',
        });
        document.body.appendChild(popup);
        return popup;
    }

    const previewPopup = createPreviewPopup();

    function clearPreviewPopup() {
        while (previewPopup.firstChild) {
            previewPopup.removeChild(previewPopup.firstChild);
        }
    }

    window.preview = function(event) {
        const link = event.currentTarget;
        const href = link.getAttribute('href');
        if (!href) return;

        clearPreviewPopup();

        if (isImageFile(href)) {
            const img = document.createElement('img');
            img.src = href;
            img.style.width = '100%';
            img.style.height = '100%';
            img.style.objectFit = 'contain';
            previewPopup.appendChild(img);
            previewPopup.style.display = 'block';
        } else if (isPdfFile(href)) {
            const iframe = document.createElement('iframe');
            iframe.src = href;
            iframe.style.width = '100%';
            iframe.style.height = '100%';
            iframe.style.border = 'none';
            previewPopup.appendChild(iframe);
            previewPopup.style.display = 'block';
        } else {
            previewPopup.style.display = 'none';
        }
    };

    window.hidePreview = function() {
        previewPopup.style.display = 'none';
        clearPreviewPopup();
    };

    function attachPreviewHandlers() {
        const allLinks = document.querySelectorAll('.dropdown-menu a[href]');
        allLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (link.dataset.previewBound) return;
            if (!href) return;
            if (!(isImageFile(href) || isPdfFile(href))) return;

            link.addEventListener('mouseover', window.preview);
            link.addEventListener('mouseout', window.hidePreview);
            link.dataset.previewBound = 'true';
        });
    }

    const observer = new MutationObserver(() => attachPreviewHandlers());
    observer.observe(document.body, { childList: true, subtree: true });

    attachPreviewHandlers();

})();
 //13.08.2025
