 (function() {
     'use strict';

     if (location.search.includes('dummy=1')) {
         console.log('Dummy page detected, skrypt nie wykonuje się tutaj.');
         return;
     }

     const localStorageInputPage = `
 <!DOCTYPE html>
 <html lang="en">
 <head>
 <meta charset="UTF-8" />
 <title>NOWA HAG LISTA</title>
 <style>
   body { font-family: Arial; background:#2c2c2c; color:#f0f0f0; padding:20px; display:flex; justify-content:center; min-height:100vh; margin:0; }
   .container { width:50%; min-width:300px; background:#3a3a3a; padding:20px 30px; border-radius:8px; box-sizing:border-box; box-shadow:0 0 10px rgba(0,0,0,0.7); margin-left:25%; margin-right:25%; }
   h2,h3 { text-align:center; margin-top:0; color:#eaeaea; }
   input { width:100%; padding:12px; font-size:16px; box-sizing:border-box; border-radius:4px; border:none; margin-top:10px; }
   .info { margin-top:10px; font-size:14px; color:#ccc; text-align:center; min-height:20px; }
   .list { margin-top:20px; background:#4a4a4a; border-radius:6px; padding:10px 15px; }
   .list ul { padding-left:0; list-style:none; margin:0; }
   .list li { margin-bottom:6px; font-family: monospace; display:flex; justify-content:space-between; align-items:center; background:#5a5a5a; padding:6px 10px; border-radius:4px; color:#eee; }
   .delete-btn { background:none; border:none; color:#ff6b6b; cursor:pointer; font-size:18px; transition: color 0.3s ease; }
   .delete-btn:hover { color:#ff3b30; }
   #clearAllBtn { display:block; margin:20px auto 0 auto; padding:12px 24px; background-color:#ff3b30; color:white; border:none; border-radius:6px; cursor:pointer; font-weight:bold; font-size:16px; transition: background-color 0.3s ease; }
   #clearAllBtn:hover { background-color:#e02922; }
   .copyright { margin-bottom:15px; text-align:center; color:#3a3a3a; margin-top:30px; font-size:14px; font-weight:bold; }
 </style>
 </head>
 <body>
 <div class="container">
   <h2>WKLEJ KOD</h2>
   <input type="text" id="listInput" placeholder="WKLEJ KOD..." />
   <div class="info" id="status"></div>
   <div class="list">
     <h3>ZAPISANE KODY: <span id="codesCount">0</span></h3>
     <ul id="savedCodesList"></ul>
   </div>
   <button id="clearAllBtn">WYCZYŚĆ WSZYSTKO</button>
   <div class="copyright">
     Sebastian Zborowski
   </div>
 </div>
 <script>
 (function() {
     const input = document.getElementById('listInput');
     const status = document.getElementById('status');
     const savedList = document.getElementById('savedCodesList');

     function getSavedCodes() {
         const data = localStorage.getItem('GSX_ListCodes');
         return data ? JSON.parse(data) : [];
     }

     function saveCode(val) {
         const codes = getSavedCodes();
         codes.push(val);
         localStorage.setItem('GSX_ListCodes', JSON.stringify(codes));
     }

     function renderSavedCodes() {
         const codes = getSavedCodes();
         savedList.innerHTML = '';
         document.getElementById('codesCount').textContent = codes.length;

         const counts = {};
         codes.forEach(code => { counts[code.toUpperCase()] = (counts[code.toUpperCase()]||0)+1; });

         const colors = ['#fc8803','#ff1500','#5b9124','#1cb07f','#ce47ff','#8c2058','#2e3e42','#537354','#5e5c24','#473730'];
         const codeColors = {};
         let colorIndex = 0;
         Object.keys(counts).forEach(code=>{
             if(counts[code]>1){ codeColors[code]=colors[colorIndex%colors.length]; colorIndex++; }
         });

         const uniqueCodes = [];
         const duplicateCodesGroups = {};
         codes.forEach(code=>{
             const upper = code.toUpperCase();
             if(counts[upper]===1) uniqueCodes.push(code);
             else { if(!duplicateCodesGroups[upper]) duplicateCodesGroups[upper]=[]; duplicateCodesGroups[upper].push(code);}
         });

         let startIndex=1;
         uniqueCodes.forEach(code=>{
             const li = document.createElement('li');
             li.textContent = startIndex+'. '+code;
             const del = document.createElement('button');
             del.className='delete-btn'; del.textContent='❌'; del.title='Delete this HAG code';
             del.addEventListener('click', ()=>{
                 const updatedCodes = getSavedCodes();
                 const idx = updatedCodes.indexOf(code);
                 if(idx!==-1){ updatedCodes.splice(idx,1); localStorage.setItem('GSX_ListCodes',JSON.stringify(updatedCodes)); renderSavedCodes(); }
             });
             li.appendChild(del); savedList.appendChild(li); startIndex++;
         });

         Object.keys(duplicateCodesGroups).forEach(dupCode=>{
             const group = duplicateCodesGroups[dupCode];
             const bgColor = codeColors[dupCode];
             group.forEach(code=>{
                 const li=document.createElement('li');
                 li.style.backgroundColor=bgColor;
                 li.textContent=startIndex+'. '+code;
                 const del = document.createElement('button');
                 del.className='delete-btn'; del.textContent='❌'; del.title='Delete this HAG code';
                 del.addEventListener('click', ()=>{
                     const updatedCodes = getSavedCodes();
                     const idx = updatedCodes.indexOf(code);
                     if(idx!==-1){ updatedCodes.splice(idx,1); localStorage.setItem('GSX_ListCodes',JSON.stringify(updatedCodes)); renderSavedCodes(); }
                 });
                 li.appendChild(del); savedList.appendChild(li); startIndex++;
             });
         });
     }

     input.addEventListener('input', ()=>{
         const val=input.value.trim();
         if(val.length>=10){
             const prefix=val.substring(0,3).toUpperCase();
             if(prefix==='HAG'){ saveCode(val); status.textContent='Zapisano do localStorage ✅'; input.value=''; input.focus(); renderSavedCodes(); }
             else{ status.textContent='Błąd. kod musi zaczynać się od: "HAG" ❌'; }
         } else status.textContent='';
     });

     document.getElementById('clearAllBtn').addEventListener('click',()=>{
         const codes = getSavedCodes().filter(c=>!c.toUpperCase().startsWith('HAG'));
         localStorage.setItem('GSX_ListCodes', JSON.stringify(codes));
         renderSavedCodes();
         status.textContent='Wyczyszczono wszystkie zapisane kody HAG ✅';
     });

     renderSavedCodes();
 })();
 </script>
 `;

     function addButtons(modal) {
         if (!modal || modal.querySelector('#createListButton')) return;

         const footer = modal.querySelector('.el-dialog__footer');
         const container = footer || modal;

         const buttonContainer = document.createElement('div');
         buttonContainer.style.display = 'flex';
         buttonContainer.style.justifyContent = 'center';
         buttonContainer.style.gap = '10px';
         buttonContainer.style.marginTop = '15px';
         buttonContainer.style.marginBottom = '15px';

         const createButton = document.createElement('button');
         createButton.id = 'createListButton';
         createButton.textContent = 'NOWA LISTA';
         Object.assign(createButton.style, { padding:'8px 16px', backgroundColor:'#007aff', color:'#fff', border:'none', borderRadius:'4px', cursor:'pointer' });
         createButton.addEventListener('click',()=>{
             const newWin = window.open('about:blank','_blank');
             if(newWin){ newWin.document.open(); newWin.document.write(localStorageInputPage); newWin.document.close(); }
             else alert('Blokada wyskakujących okienek - proszę zezwolić na otwieranie nowych kart.');
         });

         const loadButton = document.createElement('button');
         loadButton.id='loadFromListButton';
         loadButton.textContent='WCZYTAJ Z LISTY';
         Object.assign(loadButton.style,{ padding:'8px 16px', backgroundColor:'#007aff', color:'#fff', border:'none', borderRadius:'4px', cursor:'pointer' });
         loadButton.addEventListener('click', loadFromList);

         buttonContainer.appendChild(createButton);
         buttonContainer.appendChild(loadButton);
         container.appendChild(buttonContainer);
     }

     function loadFromList() {
         const codes = JSON.parse(localStorage.getItem('GSX_ListCodes')||'[]');
         const hagCodes = codes.filter(c=>c.toUpperCase().startsWith('HAG'));
         if(hagCodes.length===0){ alert('Brak kodów zaczynających się od HAG w localStorage'); return; }

         const input = document.querySelector('input.el-input__inner[data-tid="parts_selector_searchbox"]');
         if(!input){ alert('Pole wyszukiwania nie znalezione na stronie'); return; }

         let currentIndex=0;

         function searchNext(){
             if(currentIndex>=hagCodes.length){ alert('Dodano wszystkie kody z listy.'); return; }
             const currentCode=hagCodes[currentIndex];
             input.value=currentCode;
             input.focus();
             input.dispatchEvent(new Event('input',{bubbles:true}));
             input.dispatchEvent(new Event('change',{bubbles:true}));
             input.dispatchEvent(new KeyboardEvent('keydown',{bubbles:true,cancelable:true,key:'Enter',code:'Enter',keyCode:13,which:13}));

             setTimeout(()=>checkResults(currentCode),500);
         }

         function checkResults(currentCode,retries=10){
             const rows = Array.from(document.querySelectorAll('div.ag-row[aria-rowindex]:not([style*="display: none"])'));
             const noResults = document.querySelector('div.ag-overlay-no-rows-wrapper:visible span.static-table_blank');
             if(noResults && noResults.textContent.trim()==='No results found'){ input.blur(); currentIndex++; setTimeout(searchNext,300); alert(`Kod ${currentCode} nie istnieje w bazie.`); return; }

             if(rows.length===1){
                 const checkbox = rows[0].querySelector('input[type="checkbox"].custom-checkbox');
                 if(checkbox && !checkbox.checked){ checkbox.focus(); checkbox.click(); checkbox.blur(); rows[0].classList.add('ag-row-selected'); }
                 currentIndex++; setTimeout(searchNext,300);
             } else if(rows.length>1){
                 alert(`Znaleziono ${rows.length} elementów dla kodu ${currentCode}. Proszę zaznacz ręcznie.`);
                 rows.forEach(r=>{
                     const cb = r.querySelector('input[type="checkbox"].custom-checkbox');
                     if(cb){ cb.addEventListener('change', ()=>{ currentIndex++; searchNext(); }, {once:true}); }
                 });
             } else if(retries>0){ setTimeout(()=>checkResults(currentCode,retries-1),300); }
             else { currentIndex++; setTimeout(searchNext,300); }
         }

         searchNext();
     }

     function init() {
         const observer = new MutationObserver((mutations)=>{
             mutations.forEach(mutation=>{
                 mutation.addedNodes.forEach(node=>{
                     if(node.nodeType===1 && node.classList.contains('returns-parts-modal')){
                         addButtons(node);
                     }
                 });
             });
         });
         observer.observe(document.body,{childList:true,subtree:true});
     }

     init();
 })();
//13.08.2025
