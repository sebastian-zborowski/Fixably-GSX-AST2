(function () {
    'use strict';

    const serial = new URLSearchParams(location.search).get('serial');
    if (serial) {
        const tryFill = setInterval(() => {
            const input = document.querySelector('input#serial-input');
            if (input) {
                clearInterval(tryFill);
                const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                nativeInputValueSetter.call(input, serial);
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
            }
        }, 300);
    }
})();
//13.08.2025
