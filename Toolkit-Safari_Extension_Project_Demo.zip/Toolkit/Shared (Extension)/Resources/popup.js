const scriptsList = [
  { id: "PHOTO_PREVIEW", name: "PHOTO_PREVIEW", icon: "https://cdn.prod.website-files.com/605c419c1fff37864e13ab98/60b73e4b3ecef03cf244861f_fixably-favicon.png", platform: "Fixably", default: true },
  { id: "INTERFACE_TWEAKS", name: "INTERFACE_TWEAKS", icon: "https://cdn.prod.website-files.com/605c419c1fff37864e13ab98/60b73e4b3ecef03cf244861f_fixably-favicon.png", platform: "Fixably", default: true },
  { id: "PASTE_LINK", name: "PASTE_LINK", icon: "https://diagnostics.apple.com/static/projects/aide/images/favicon-64x64.ico", platform: "AST2", default: true },
  { id: "ADD_PARTS", name: "ADD_PARTS", icon: "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://gsx2.apple.com/&size=128", platform: "GSX", default: false },
  { id: "OPEN_GNUM", name: "OPEN_GNUM", icon: "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://gsx2.apple.com/&size=128", platform: "GSX", default: true },
  { id: "ACTION_REQUIRED", name: "ACTION_REQUIRED", icon: "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://gsx2.apple.com/&size=128", platform: "GSX", default: false },
  { id: "CLIENT_PASTE", name: "CLIENT_PASTE", icon: "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://gsx2.apple.com/&size=128", platform: "GSX", default: true },
  { id: "CLIENT_COPY", name: "CLIENT_COPY", icon: "https://servo.ispot.pl/static/images/apple-touch-icon.png", platform: "Servo", default: true },
  { id: "author", name: "Sebastian Zborowski", icon: "", platform: "", default: true, isAuthor: true, link: "https://www.linkedin.com/in/sebastian-zborowski-072853218/" }
];

function buildTable() {
  const tbody = document.querySelector("#toolkitTable tbody");
  const checkboxes = {};

  scriptsList.forEach(script => {
    if (script.isAuthor) {
      const tr = document.createElement("tr");
      tr.className = "author";
      const td = document.createElement("td");
      td.colSpan = 4;
      td.innerHTML = `<strong>${script.name}</strong><a href="${script.link}" target="_blank">LinkedIn</a>`;
      tr.appendChild(td);
      tbody.appendChild(tr);
      return;
    }

    const tr = document.createElement("tr");

    // Nazwa
    const nameTd = document.createElement("td");
    nameTd.textContent = script.name;
    tr.appendChild(nameTd);

    // Ikona
    const iconTd = document.createElement("td");
    iconTd.style.textAlign = "center";
    const img = document.createElement("img");
    img.src = script.icon;
    img.width = 25;
    img.height = 25;
    iconTd.appendChild(img);
    tr.appendChild(iconTd);

    // Platforma
    const platformTd = document.createElement("td");
    platformTd.textContent = script.platform;
    platformTd.style.textAlign = "center";
    tr.appendChild(platformTd);

    // Toggle
    const activeTd = document.createElement("td");
    activeTd.style.textAlign = "center";
    const label = document.createElement("label");
    label.className = "switch";
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    const slider = document.createElement("span");
    slider.className = "slider";
    label.appendChild(checkbox);
    label.appendChild(slider);
    activeTd.appendChild(label);
    tr.appendChild(activeTd);

    checkboxes[script.id] = checkbox;

    // Pobranie stanu z storage
    chrome.storage.local.get(script.id, data => {
      if (data[script.id] === undefined) {
        checkbox.checked = script.default;
        chrome.storage.local.set({ [script.id]: script.default });
      } else {
        checkbox.checked = data[script.id];
      }
    });

    // Obsługa zmiany toggle
    checkbox.addEventListener("change", () => {
      chrome.storage.local.set({ [script.id]: checkbox.checked });
      chrome.runtime.sendMessage({ type: "toggle_changed", id: script.id, enabled: checkbox.checked });
    });

    tbody.appendChild(tr);
  });
}

document.addEventListener("DOMContentLoaded", buildTable);
