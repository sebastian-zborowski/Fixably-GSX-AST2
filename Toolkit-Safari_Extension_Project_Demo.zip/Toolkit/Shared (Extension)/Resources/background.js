// Wstrzyknięcie pojedynczego skryptu w aktywnej karcie
function injectScript(tabId, scriptId) {
  browser.scripting.executeScript({
    target: { tabId },
    files: [`${scriptId}.js`]
  }).then(() => console.log(`Injected: ${scriptId}`))
    .catch(err => console.error(`Failed to inject ${scriptId}:`, err));
}

// Nasłuch toggle z popup
browser.runtime.onMessage.addListener(msg => {
  if (msg.type === "toggle_changed") {
    if (msg.enabled) {
      browser.tabs.query({ active: true, currentWindow: true }).then(tabs => {
        if (!tabs[0]) return;

        // Specjalny warunek tylko dla ADD_PARTS
        if (msg.id === "ADD_PARTS") {
          if (tabs[0].url && tabs[0].url.startsWith("https://gsx2.apple.com/returns/new?from=sp_so_draft")) {
            injectScript(tabs[0].id, msg.id);
          } else {
            console.log("ADD_PARTS pominięty – nie na odpowiedniej stronie");
          }
        } else {
          injectScript(tabs[0].id, msg.id);
        }
      });
    }
  }
});

// Wstrzykiwanie włączonych skryptów przy każdej zmianie strony
browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;

  browser.storage.local.get(null).then(toggles => {
    Object.entries(toggles).forEach(([scriptId, enabled]) => {
      if (!enabled || scriptId === "author") return;

      if (scriptId === "ADD_PARTS") {
        if (tab.url && tab.url.startsWith("https://gsx2.apple.com/returns/new?from=sp_so_draft")) {
          injectScript(tabId, scriptId);
        } else {
          console.log("ADD_PARTS pominięty – nie na odpowiedniej stronie");
        }
      } else {
        injectScript(tabId, scriptId);
      }
    });
  });
});
